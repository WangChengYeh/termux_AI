#!/data/data/com.termux/files/usr/bin/sh

echo "$@"
